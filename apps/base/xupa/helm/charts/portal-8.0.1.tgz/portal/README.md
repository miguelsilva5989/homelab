# portal

Mobileum portal integration all the products together on a single UI

## Requirements

Kubernetes: `>=1.16.0-0`

| Repository | Name | Version |
|------------|------|---------|
| oci://162015117822.dkr.ecr.eu-west-1.amazonaws.com/aip-charts | aip-common | 0.13.1 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| automountServiceAccountToken | bool | `false` |  |
| autoscaling.behaviors.enabled | bool | `false` |  |
| autoscaling.behaviors.scaleDown.enabled | bool | `false` |  |
| autoscaling.behaviors.scaleDown.percent.period | int | `60` |  |
| autoscaling.behaviors.scaleDown.percent.value | int | `0` |  |
| autoscaling.behaviors.scaleDown.pods.enabled | bool | `false` |  |
| autoscaling.behaviors.scaleDown.pods.period | int | `60` |  |
| autoscaling.behaviors.scaleDown.pods.value | int | `0` |  |
| autoscaling.behaviors.scaleDown.selectPolicy | string | `"Min"` |  |
| autoscaling.behaviors.scaleDown.stabilizationWindow | int | `300` |  |
| autoscaling.behaviors.scaleUp.enabled | bool | `false` |  |
| autoscaling.behaviors.scaleUp.percent.period | int | `60` |  |
| autoscaling.behaviors.scaleUp.percent.value | int | `0` |  |
| autoscaling.behaviors.scaleUp.pods.enabled | bool | `false` |  |
| autoscaling.behaviors.scaleUp.pods.period | int | `60` |  |
| autoscaling.behaviors.scaleUp.pods.value | int | `0` |  |
| autoscaling.behaviors.scaleUp.selectPolicy | string | `"Min"` |  |
| autoscaling.behaviors.scaleUp.stabilizationWindow | int | `300` |  |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.kind | string | `"Deployment"` |  |
| autoscaling.maxReplicas | int | `3` |  |
| autoscaling.metrics.cpuPercent | int | `90` |  |
| autoscaling.metrics.custom | object | `{}` |  |
| autoscaling.metrics.customEnabled | bool | `false` |  |
| autoscaling.metrics.memoryPercent | int | `95` |  |
| autoscaling.minReplicas | int | `1` |  |
| containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| containerSecurityContext.enabled | bool | `true` |  |
| containerSecurityContext.privileged | bool | `false` |  |
| customPodAnnotations | object | `{}` |  |
| customPodLabels | object | `{}` |  |
| deployment.env.devMode | string | `""` |  |
| deployment.env.httpRelativePath | string | `"/"` |  |
| deployment.env.keycloakClientId | string | `""` |  |
| deployment.env.keycloakRealm | string | `""` |  |
| deployment.env.keycloakURL | string | `""` |  |
| deployment.env.onlineHelpURL | string | `""` |  |
| deployment.env.pageManagerURL | string | `""` |  |
| deployment.env.portalTitle | string | `""` |  |
| deployment.env.pushNotificationsURL | string | `""` |  |
| deployment.env.reportingServiceURL | string | `""` |  |
| deployment.env.timezone | string | `"UTC"` |  |
| deployment.envConfigMap | string | `""` |  |
| deployment.envSecret | string | `""` |  |
| deployment.replicas | string | `"1"` |  |
| deployment.resources.limits.cpu | string | `"1"` |  |
| deployment.resources.limits.memory | string | `"4098Mi"` |  |
| deployment.resources.requests.cpu | string | `"1"` |  |
| deployment.resources.requests.memory | string | `"2048Mi"` |  |
| deployment.safeToEvict | bool | `true` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.pullSecrets | list | `[]` |  |
| image.registry | string | `""` |  |
| image.repository | string | `"aip/portal"` |  |
| image.tag | string | `"5.0.0"` |  |
| nodeAffinity | object | `{}` |  |
| patches.configMaps | list | `[]` |  |
| podAffinity | object | `{}` |  |
| podAntiAffinity | object | `{}` |  |
| podSecurityContext.enabled | bool | `false` |  |
| service.annotation | object | `{}` |  |
| service.ipFamilies[0] | string | `"IPv4"` |  |
| service.ipFamilyPolicy | string | `"SingleStack"` |  |
| service.labels | object | `{}` |  |
| service.nodePort | string | `""` |  |
| service.port | int | `3001` |  |
| service.type | string | `"ClusterIP"` |  |
| testAnnotation."helm.sh/hook" | string | `"test-success"` |  |
| testAnnotation."helm.sh/hook-delete-policy" | string | `"hook-succeeded"` |  |
